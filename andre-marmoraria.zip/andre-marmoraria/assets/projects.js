document.querySelectorAll('.project').forEach((project) => {
  project.addEventListener('toggle', () => {
    const preview = project.querySelector('template');
    if (project.open && preview) {
      preview.replaceWith(preview.content.cloneNode(true));
    }
  });
});
